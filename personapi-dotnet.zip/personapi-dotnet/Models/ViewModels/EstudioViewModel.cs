﻿namespace personapi_dotnet.Models.ViewModels
{
    public class EstudioViewModel
    {
    }
}
